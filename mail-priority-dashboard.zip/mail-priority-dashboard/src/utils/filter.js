// Keyword detection + classification of emails into priority categories.
//
// How accuracy is achieved:
//  1. Clean text  – quoted replies, forwarded history, signatures and newsletter
//                   footers are removed so old/boilerplate text can't trigger matches.
//  2. Word forms  – "confirm" also matches confirmed / confirmation, "meeting" → meetings,
//                   "schedule" → scheduled. Still whole words only: "due" ≠ "procedure".
//  3. Negation    – "no action required", "not urgent", "no need to call" are ignored.
//  4. Scoring     – subject hits count more than body hits; very common words
//                   (today, call, send, update…) are "weak" and need support from
//                   another keyword or the subject before an email is flagged
//                   (unless it's a polite request: "please send", "kindly confirm").
//  5. Bulk mail   – promotions / newsletters (List-Unsubscribe, Promotions tab…) only
//                   count keywords in the subject, never marketing copy in the body.

// Common everyday words: on their own in the body they are not enough to flag an email.
export const WEAK_KEYWORDS = new Set([
  'due', 'today', 'tomorrow', 'submit', 'confirm', 'approve', 'review', 'send',
  'schedule', 'discussion', 'call', 'information', 'update',
]);

const SUBJECT_WEIGHT = 3;
const BODY_WEIGHT = 1;
const STRONG = 2;
const WEAK = 1;
const MATCH_THRESHOLD = 2; // category score needed to count as a match

const escapeRegex = (s) => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

// Build a regex fragment for one word, allowing common English word forms.
function wordForms(word) {
  const w = escapeRegex(word);
  // Acronyms (ASAP, FYI), short words and non-letters: exact only.
  if (word.length < 4 || !/^[a-z]+$/i.test(word) || word === word.toUpperCase()) return w;
  const lower = word.toLowerCase();
  if (lower.endsWith('e')) {
    // schedule → scheduled, scheduling; approve → approval; update → updates
    return `${escapeRegex(word.slice(0, -1))}(?:e|es|ed|ing|al)`;
  }
  if (lower.endsWith('y')) {
    // emergency → emergencies
    return `${escapeRegex(word.slice(0, -1))}(?:y|ies)`;
  }
  // submit → submitted / submitting, call → calls / calling, confirm → confirmation
  const last = escapeRegex(word.slice(-1));
  return `${w}(?:${last}?(?:s|es|ed|ing|ation|ations|ly))?`;
}

// Regex source for a keyword or phrase (only the last word of a phrase gets word forms).
export function keywordPattern(keyword) {
  const words = keyword.trim().split(/\s+/).filter(Boolean);
  if (!words.length) return null;
  const head = words.slice(0, -1).map(escapeRegex);
  return [...head, wordForms(words[words.length - 1])].join('[\\s\\-]+');
}

export function keywordRegex(keyword, flags = 'giu') {
  const p = keywordPattern(keyword);
  return p ? new RegExp(`(?<![\\p{L}\\p{N}])${p}(?![\\p{L}\\p{N}])`, flags) : null;
}

// "no action required", "not urgent", "non-urgent", "no need to call", "nothing urgent"
const NEGATION = /(?:^|[^\p{L}])(?:no|not|non|nothing|never|without)[\s-]+(?:(?:really|so|very|an?|the|any|need\s+to|further|immediate)\s+)?$/iu;

// "please send", "kindly confirm", "pls review" – a polite request makes a weak word strong.
const REQUEST = /(?:^|[^\p{L}])(?:please|kindly|pls|plz)\s+$/iu;

// Count non-negated occurrences of a keyword regex in text.
function countHits(re, text) {
  const result = { count: 0, requested: false };
  if (!text) return result;
  re.lastIndex = 0;
  let m;
  while ((m = re.exec(text)) !== null) {
    const before = text.slice(Math.max(0, m.index - 30), m.index);
    if (!NEGATION.test(before)) {
      result.count += 1;
      if (REQUEST.test(before)) result.requested = true;
    }
    if (m[0].length === 0) re.lastIndex += 1;
  }
  return result;
}

// ---------- Text cleaning ----------

const FOOTER_LINE = /unsubscribe|view (?:this (?:email|message) )?(?:in|on) (?:your |a )?(?:browser|web)|privacy policy|all rights reserved|©|manage (?:your )?(?:email )?(?:preferences|subscriptions?|notifications)|you (?:are )?receiv(?:ed|ing) this|email preferences|terms of (?:service|use)|sent from my (?:iphone|android|phone)/i;

export function normalizeText(text = '') {
  return text
    .normalize('NFKC')
    .replace(/[ ​-‍⁠﻿]/g, ' ')
    .replace(/[‘’]/g, "'")
    .replace(/[“”]/g, '"');
}

// Keep only the new part of the message: drop quoted replies, forwarded history,
// signatures and newsletter footers.
export function cleanBody(text = '') {
  let t = normalizeText(text).replace(/\r\n?/g, '\n');

  const cutMarkers = [
    /\n[^\n]{0,20}On [^\n]{3,200}wrote:\s*\n/i,             // Gmail reply header
    /\n[^\n]{0,10}-{2,}\s*(?:Original|Forwarded) Message\s*-{2,}/i,
    /\n\s*From:\s[^\n]+\n\s*(?:Sent|Date):\s/i,               // Outlook reply header
    /\n\s*_{10,}\s*\n/,                                        // Outlook separator
    /\n--\s*\n/,                                               // signature delimiter
  ];
  cutMarkers.forEach((re) => {
    const m = re.exec(`\n${t}`);
    if (m && m.index > 0) t = t.slice(0, m.index);
  });

  return t
    .split('\n')
    .filter((line) => !/^\s*>/.test(line) && !FOOTER_LINE.test(line))
    .join('\n')
    .replace(/[ \t]+/g, ' ')
    .replace(/\n\s*\n+/g, '\n')
    .trim()
    .slice(0, 8000);
}

// ---------- Classification ----------

// Compile once per categories change.
export function compileCategories(categories) {
  return categories.map((cat, index) => ({
    ...cat,
    rank: index,
    matchers: cat.keywords
      .map((k) => k.trim())
      .filter(Boolean)
      .map((k) => ({
        keyword: k,
        re: keywordRegex(k),
        strength: WEAK_KEYWORDS.has(k.toLowerCase()) ? WEAK : STRONG,
      })),
  }));
}

export function classifyEmail(email, compiled) {
  const subject = normalizeText(email.subject || '');
  const bulk = Boolean(email.bulk);
  // Bulk mail: ignore the marketing body, only trust the subject.
  const body = bulk ? '' : email.matchText ?? cleanBody(email.text || email.snippet || '');

  const matches = [];
  let total = 0;

  compiled.forEach((cat) => {
    const hits = [];
    let catScore = 0;
    cat.matchers.forEach(({ keyword, re, strength }) => {
      const subj = countHits(re, subject);
      const bod = countHits(re, body);
      const inSubject = subj.count > 0;
      if (!inSubject && !bod.count) return;
      const where = inSubject ? SUBJECT_WEIGHT : BODY_WEIGHT;
      const power = subj.requested || bod.requested ? STRONG : strength;
      // Repeated body mentions add a little confidence (max +1).
      const repeat = !inSubject && bod.count > 1 ? Math.min(bod.count - 1, 2) * 0.5 : 0;
      catScore += where * power + repeat;
      hits.push({ keyword, where: inSubject ? 'subject' : 'body' });
    });
    if (catScore >= MATCH_THRESHOLD) {
      matches.push({ categoryId: cat.id, keywords: hits.map((h) => h.keyword), hits, score: catScore });
      total += catScore * (compiled.length - cat.rank);
    }
  });

  // Promotions / newsletters always land in the low-priority category (if it exists).
  if (bulk && compiled.some((c) => c.id === 'low') && !matches.some((m) => m.categoryId === 'low')) {
    matches.push({ categoryId: 'low', keywords: ['newsletter / promotion (auto)'], hits: [], score: MATCH_THRESHOLD });
  }
  matches.sort((a, b) => compiled.findIndex((c) => c.id === a.categoryId) - compiled.findIndex((c) => c.id === b.categoryId));

  const importantIds = new Set(compiled.filter((c) => c.important).map((c) => c.id));
  const importantMatches = matches.filter((m) => importantIds.has(m.categoryId));
  const important = importantMatches.length > 0;
  const primary = matches.length ? matches[0].categoryId : null;
  const rank = primary ? compiled.findIndex((c) => c.id === primary) : compiled.length;

  const best = Math.max(0, ...importantMatches.map((m) => m.score));
  const confidence = !important ? null : best >= 6 ? 'High' : best >= 3 ? 'Medium' : 'Low';

  return { matches, primary, important, score: total, rank, confidence, bulk };
}

// Priority order: highest category first (Urgent > Deadline > …), then score, then newest.
export function byPriority(a, b) {
  return a.cls.rank - b.cls.rank || b.cls.score - a.cls.score || b.date - a.date;
}

// Regex that matches any keyword (with word forms) – used for highlighting.
export function allKeywordsRegex(categories) {
  const words = [...new Set(categories.flatMap((c) => c.keywords).map((k) => k.trim()).filter(Boolean))];
  if (!words.length) return null;
  words.sort((a, b) => b.length - a.length);
  const body = words.map(keywordPattern).filter(Boolean).join('|');
  return new RegExp(`(?<![\\p{L}\\p{N}])(?:${body})(?![\\p{L}\\p{N}])`, 'giu');
}
