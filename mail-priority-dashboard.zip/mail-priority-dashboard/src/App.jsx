import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import Login from './components/Login.jsx';
import Sidebar from './components/Sidebar.jsx';
import Topbar from './components/Topbar.jsx';
import Dashboard from './components/Dashboard.jsx';
import MailView from './components/MailView.jsx';
import KeywordManager from './components/KeywordManager.jsx';
import { DEFAULT_CATEGORIES } from './config/keywords.js';
import { classifyEmail, compileCategories } from './utils/filter.js';
import {
  AuthError, clearToken, getMessages, getProfile, getChanges, getStoredToken, getUnreadIds, listMessageIds, onRateLimit, signIn,
} from './services/gmail.js';

const PAGE_SIZE = 50;
const AUTO_REFRESH_MS = 15_000; // history checks are cheap (2 quota units)
const CATEGORIES_KEY = 'mpd_categories';

function loadCategories() {
  try {
    const saved = JSON.parse(localStorage.getItem(CATEGORIES_KEY));
    if (Array.isArray(saved) && saved.length) return saved;
  } catch {
    /* ignore */
  }
  return DEFAULT_CATEGORIES;
}

export default function App() {
  const [mode, setMode] = useState(null); // 'gmail' when signed in, otherwise null
  const [token, setToken] = useState(null);
  const [user, setUser] = useState(null);
  const [emails, setEmails] = useState([]);
  const [nextPageToken, setNextPageToken] = useState(null);
  const [status, setStatus] = useState({ loading: false, loadingMore: false, refreshing: false });
  const [error, setError] = useState('');
  const [lastSync, setLastSync] = useState(null);
  const [categories, setCategories] = useState(loadCategories);
  const [view, setView] = useState('dashboard');
  const [search, setSearch] = useState('');
  const [selectedId, setSelectedId] = useState(null);
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [notice, setNotice] = useState('');
  const emailsRef = useRef(emails);
  emailsRef.current = emails;
  const [toast, setToast] = useState('');
  const busyRef = useRef(false); // only one Gmail operation at a time (saves API quota)
  const pendingSyncRef = useRef(false); // a sync was requested while busy → run it right after
  const refreshRef = useRef(null);
  const accountRef = useRef('me');
  const historyIdRef = useRef(null); // Gmail mailbox "version" – used to fetch only changes
  const readLocallyRef = useRef(new Set()); // emails opened here (Gmail still says unread)

  useEffect(() => {
    onRateLimit((seconds) => setNotice(`Gmail's per-minute limit was reached — waiting ${seconds}s, then continuing automatically…`));
  }, []);

  useEffect(() => {
    if (!toast) return undefined;
    const t = setTimeout(() => setToast(''), 3500);
    return () => clearTimeout(t);
  }, [toast]);

  // Run a Gmail operation unless another one is already running. A sync requested
  // while busy is not dropped – it runs as soon as the current operation finishes.
  const runExclusive = useCallback(async (key, fn) => {
    if (busyRef.current) {
      if (key === 'refreshing') pendingSyncRef.current = true;
      return;
    }
    busyRef.current = true;
    setStatus((s) => ({ ...s, [key]: true }));
    try {
      await fn();
    } catch (err) {
      handleErrorRef.current(err);
    } finally {
      busyRef.current = false;
      setNotice('');
      setStatus((s) => ({ ...s, [key]: false }));
      if (pendingSyncRef.current) {
        pendingSyncRef.current = false;
        setTimeout(() => refreshRef.current?.({ silent: true }), 0);
      }
    }
  }, []);

  // Keep read/unread state in sync with Gmail (1 cheap API call).
  const syncUnread = async (tok) => {
    const { ids, complete } = await getUnreadIds(tok);
    setEmails((prev) =>
      prev.map((e) => {
        const unread = (complete ? ids.has(e.id) : ids.has(e.id) || e.unread) && !readLocallyRef.current.has(e.id);
        return unread === e.unread ? e : { ...e, unread };
      })
    );
  };

  useEffect(() => {
    try {
      localStorage.setItem(CATEGORIES_KEY, JSON.stringify(categories));
    } catch {
      /* ignore */
    }
  }, [categories]);

  const handleError = useCallback((err) => {
    if (err instanceof AuthError) {
      setMode(null);
      setToken(null);
      setEmails([]);
    }
    setError(err.message || String(err));
  }, []);
  const handleErrorRef = useRef(handleError);

  // ---------- Loading ----------

  const loadInbox = useCallback((tok) => runExclusive('loading', async () => {
    setError('');
    // Profile first: its historyId marks "now", so anything arriving later is caught by sync.
    const profile = await getProfile(tok);
    historyIdRef.current = profile.historyId;
    const page = await listMessageIds(tok, { maxResults: PAGE_SIZE });
    accountRef.current = profile.emailAddress;
    setUser({ email: profile.emailAddress, total: profile.messagesTotal });
    const msgs = await getMessages(tok, page.ids, accountRef.current);
    setEmails(msgs.sort((a, b) => b.date - a.date));
    setNextPageToken(page.nextPageToken);
    await syncUnread(tok);
    setLastSync(Date.now());
  }), [runExclusive]);

  // Restore an existing session on page reload (guarded: React dev mode runs effects twice).
  const restoredRef = useRef(false);
  useEffect(() => {
    if (restoredRef.current) return;
    restoredRef.current = true;
    const saved = getStoredToken();
    if (saved) {
      setToken(saved);
      setMode('gmail');
      loadInbox(saved);
    }
  }, [loadInbox]);

  const handleSignIn = async () => {
    setError('');
    try {
      const tok = await signIn();
      setToken(tok);
      setMode('gmail');
      loadInbox(tok);
    } catch (err) {
      setError(err.message);
    }
  };

  const handleLogout = () => {
    clearToken();
    setMode(null);
    setToken(null);
    setUser(null);
    setEmails([]);
    setSelectedId(null);
    setView('dashboard');
    readLocallyRef.current = new Set();
  };

  const loadMore = () => {
    if (!nextPageToken || mode !== 'gmail') return;
    runExclusive('loadingMore', async () => {
      const page = await listMessageIds(token, { maxResults: PAGE_SIZE, pageToken: nextPageToken });
      const known = new Set(emailsRef.current.map((e) => e.id));
      const msgs = await getMessages(token, page.ids.filter((id) => !known.has(id)), accountRef.current);
      setEmails((prev) => [...prev, ...msgs].sort((a, b) => b.date - a.date));
      setNextPageToken(page.nextPageToken);
    });
  };

  // Real-time sync: ask Gmail what changed since the last sync (new mail, read/unread,
  // archived/deleted) and apply only those changes.
  const syncChanges = async (tok) => {
    let changes;
    try {
      changes = await getChanges(tok, historyIdRef.current);
    } catch (err) {
      if (err.status !== 404 && err.status !== 400) throw err;
      // History too old (e.g. laptop slept for days): fall back to checking the latest emails.
      const profile = await getProfile(tok);
      const page = await listMessageIds(tok, { maxResults: PAGE_SIZE });
      changes = { historyId: profile.historyId, added: page.ids, removed: [], unread: {} };
      await syncUnread(tok);
    }

    const known = new Set(emailsRef.current.map((e) => e.id));
    const newIds = changes.added.filter((id) => !known.has(id));
    const newMsgs = newIds.length ? await getMessages(tok, newIds, accountRef.current) : [];
    const removed = new Set(changes.removed);

    Object.entries(changes.unread).forEach(([id, isUnread]) => {
      if (isUnread) readLocallyRef.current.delete(id); // marked unread in Gmail again
    });

    setEmails((prev) =>
      [...newMsgs, ...prev.filter((e) => !removed.has(e.id))]
        .map((e) => {
          const u = changes.unread[e.id];
          if (u === undefined) return e;
          const unread = u && !readLocallyRef.current.has(e.id);
          return unread === e.unread ? e : { ...e, unread };
        })
        .sort((a, b) => b.date - a.date)
    );
    historyIdRef.current = changes.historyId;
    return newMsgs.length;
  };

  const refresh = useCallback(({ silent = false } = {}) => {
    if (mode !== 'gmail' || !token) return;
    runExclusive('refreshing', async () => {
      const count = await syncChanges(token);
      setLastSync(Date.now());
      if (count) setToast(`📬 ${count} new email${count === 1 ? '' : 's'}`);
      else if (!silent) setToast('✓ Inbox is up to date');
    });
  }, [mode, token, runExclusive]);
  refreshRef.current = refresh;

  // Auto-sync every 15s while the tab is visible, and immediately when you come back to it.
  useEffect(() => {
    if (mode !== 'gmail') return undefined;
    const t = setInterval(() => {
      if (document.visibilityState === 'visible') refresh({ silent: true });
    }, AUTO_REFRESH_MS);
    const onVisible = () => document.visibilityState === 'visible' && refresh({ silent: true });
    document.addEventListener('visibilitychange', onVisible);
    return () => {
      clearInterval(t);
      document.removeEventListener('visibilitychange', onVisible);
    };
  }, [mode, refresh]);

  // ---------- Classification ----------

  const compiled = useMemo(() => compileCategories(categories), [categories]);

  const classified = useMemo(
    () => emails.map((e) => ({ ...e, cls: classifyEmail(e, compiled) })),
    [emails, compiled]
  );

  const counts = useMemo(() => {
    const c = { all: classified.length, unread: 0, important: 0 };
    categories.forEach((cat) => (c[cat.id] = 0));
    classified.forEach((e) => {
      if (e.unread) c.unread += 1;
      if (e.cls.important) c.important += 1;
      e.cls.matches.forEach((m) => (c[m.categoryId] = (c[m.categoryId] || 0) + 1));
    });
    return c;
  }, [classified, categories]);

  const markRead = (id) => {
    // Local only (read-only Gmail permission) – just updates the dashboard view.
    readLocallyRef.current.add(id);
    setEmails((prev) => prev.map((e) => (e.id === id ? { ...e, unread: false } : e)));
  };

  // ---------- Render ----------

  if (!mode) {
    return <Login onSignIn={handleSignIn} error={error} />;
  }

  const goTo = (v) => {
    setView(v);
    setSelectedId(null);
    setSidebarOpen(false);
  };

  const openEmail = (id, fromView) => {
    if (fromView) setView(fromView);
    setSelectedId(id);
    markRead(id);
  };

  let content;
  if (view === 'dashboard') {
    content = (
      <Dashboard
        emails={classified}
        categories={categories}
        counts={counts}
        user={user}
        loading={status.loading}
        onOpen={openEmail}
        onNavigate={goTo}
        hasMore={Boolean(nextPageToken)}
        loadingMore={status.loadingMore}
        onLoadMore={loadMore}
        pageSize={PAGE_SIZE}
      />
    );
  } else if (view === 'keywords') {
    content = <KeywordManager categories={categories} onChange={setCategories} onReset={() => setCategories(DEFAULT_CATEGORIES)} />;
  } else {
    content = (
      <MailView
        view={view}
        emails={classified}
        categories={categories}
        search={search}
        loading={status.loading}
        selectedId={selectedId}
        onSelect={openEmail}
        onClose={() => setSelectedId(null)}
        hasMore={Boolean(nextPageToken)}
        loadingMore={status.loadingMore}
        onLoadMore={loadMore}
      />
    );
  }

  return (
    <div className={`app ${sidebarOpen ? 'sidebar-open' : ''}`}>
      <Sidebar view={view} counts={counts} categories={categories} onNavigate={goTo} onClose={() => setSidebarOpen(false)} />
      <div className="sidebar-backdrop" onClick={() => setSidebarOpen(false)} />
      <main className="main">
        <Topbar
          user={user}
          search={search}
          onSearch={(v) => {
            setSearch(v);
            if (v && (view === 'dashboard' || view === 'keywords')) goTo('all');
          }}
          onRefresh={() => refresh()}
          refreshing={status.refreshing}
          lastSync={lastSync}
          onLogout={handleLogout}
          onMenu={() => setSidebarOpen(true)}
        />
        {notice && (
          <div className="alert alert-info">
            <span className="spin">⟳</span> <span style={{ flex: 1 }}>{notice}</span>
          </div>
        )}
        {error && (
          <div className="alert">
            <span>⚠️ {error}</span>
            <button className="btn-ghost" onClick={() => setError('')}>Dismiss</button>
          </div>
        )}
        <div className="content">{content}</div>
        {toast && <div className="toast" role="status">{toast}</div>}
      </main>
    </div>
  );
}
