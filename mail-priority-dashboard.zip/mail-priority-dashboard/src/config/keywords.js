// Default keyword categories. Order = priority (first match wins for the main badge).
// "important: true" means emails matching this category appear in the Important list.
export const DEFAULT_CATEGORIES = [
  {
    id: 'urgent',
    name: 'Urgent',
    icon: '🔥',
    color: '#ef4444',
    important: true,
    keywords: ['urgent', 'ASAP', 'immediately', 'emergency', 'critical'],
  },
  {
    id: 'deadline',
    name: 'Deadline',
    icon: '⏰',
    color: '#f97316',
    important: true,
    keywords: ['deadline', 'due', 'today', 'tomorrow', 'by Monday', 'submit', 'last date'],
  },
  {
    id: 'action',
    name: 'Action Required',
    icon: '✅',
    color: '#8b5cf6',
    important: true,
    keywords: ['please respond', 'action required', 'confirm', 'approve', 'review', 'send', 'submit'],
  },
  {
    id: 'meeting',
    name: 'Meeting',
    icon: '📅',
    color: '#0ea5e9',
    important: true,
    keywords: ['meeting', 'schedule', 'appointment', 'discussion', 'call'],
  },
  {
    id: 'low',
    name: 'Normal / Low',
    icon: '📰',
    color: '#64748b',
    important: false,
    keywords: ['FYI', 'information', 'update', 'newsletter', 'announcement'],
  },
];
