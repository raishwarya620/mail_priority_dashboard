import Highlight from './Highlight.jsx';
import { avatarColor, formatDate, initials } from '../utils/format.js';

export default function EmailRow({ email, categoryMap, regex, active, onClick, compact }) {
  const primary = email.cls.primary ? categoryMap[email.cls.primary] : null;
  return (
    <button
      className={`email-row ${email.unread ? 'unread' : ''} ${active ? 'active' : ''} ${compact ? 'compact' : ''}`}
      onClick={onClick}
      style={primary ? { '--accent': primary.color } : undefined}
    >
      <div className="avatar" style={{ background: avatarColor(email.fromEmail) }}>{initials(email.fromName)}</div>
      <div className="email-main">
        <div className="email-top">
          <span className="email-from">{email.fromName}</span>
          <span className="email-date">{formatDate(email.date)}</span>
        </div>
        <div className="email-subject">
          {email.cls.important && <span className="star" title="Important">★</span>}
          <Highlight text={email.subject} regex={regex} />
        </div>
        {!compact && (
          <div className="email-snippet">
            <Highlight text={email.snippet} regex={regex} />
          </div>
        )}
        {email.cls.matches.length > 0 && (
          <div className="tags">
            {email.cls.matches.map((m) => {
              const cat = categoryMap[m.categoryId];
              if (!cat) return null;
              return (
                <span key={m.categoryId} className="tag" style={{ color: cat.color, background: `${cat.color}1a`, borderColor: `${cat.color}40` }}>
                  {cat.icon} {cat.name}
                </span>
              );
            })}
            {email.attachments > 0 && <span className="tag tag-muted">📎 {email.attachments}</span>}
          </div>
        )}
      </div>
    </button>
  );
}
