import { useMemo } from 'react';
import EmailRow from './EmailRow.jsx';
import { allKeywordsRegex, byPriority } from '../utils/filter.js';

function greeting() {
  const h = new Date().getHours();
  if (h < 12) return 'Good morning';
  if (h < 17) return 'Good afternoon';
  return 'Good evening';
}

export default function Dashboard({
  emails, categories, counts, user, loading, onOpen, onNavigate, hasMore, loadingMore, onLoadMore, pageSize,
}) {
  const categoryMap = useMemo(() => Object.fromEntries(categories.map((c) => [c.id, c])), [categories]);
  const regex = useMemo(() => allKeywordsRegex(categories), [categories]);

  const important = useMemo(
    () => emails.filter((e) => e.cls.important).sort(byPriority).slice(0, 6),
    [emails]
  );
  const recent = emails.slice(0, 8);
  const max = Math.max(1, ...categories.map((c) => counts[c.id] || 0));
  const name = (user?.email || '').split('@')[0];

  const stats = [
    { label: 'Emails loaded', value: counts.all, icon: '📥', grad: 'grad-indigo', go: 'all' },
    { label: 'Unread', value: counts.unread, icon: '🔵', grad: 'grad-sky', go: 'unread' },
    { label: 'Important', value: counts.important, icon: '⭐', grad: 'grad-amber', go: 'important' },
    { label: 'Urgent', value: counts.urgent || 0, icon: '🔥', grad: 'grad-rose', go: 'cat:urgent' },
  ];

  return (
    <div className="dashboard">
      <div className="hero">
        <div>
          <h1>{greeting()}, {name} 👋</h1>
          <p>
            {loading
              ? 'Fetching your latest emails from Gmail…'
              : <>You have <strong>{counts.important}</strong> important email{counts.important === 1 ? '' : 's'} and <strong>{counts.unread}</strong> unread.</>}
          </p>
        </div>
        <div className="hero-actions">
          {hasMore && (
            <button className="btn-hero-outline" onClick={onLoadMore} disabled={loadingMore || loading}>
              {loadingMore ? 'Loading…' : `Load ${pageSize} more emails`}
            </button>
          )}
          <button className="btn-primary" onClick={() => onNavigate('important')}>View important →</button>
        </div>
      </div>

      <div className="stats">
        {stats.map((s) => (
          <button key={s.label} className={`stat ${s.grad}`} onClick={() => onNavigate(s.go)}>
            <div className="stat-icon">{s.icon}</div>
            <div className="stat-value">{loading ? '–' : s.value}</div>
            <div className="stat-label">{s.label}</div>
          </button>
        ))}
      </div>

      <div className="grid-2">
        <div className="card">
          <div className="card-head">
            <h3>⭐ Important emails</h3>
            <button className="link-btn" onClick={() => onNavigate('important')}>See all</button>
          </div>
          {important.length === 0 ? (
            <div className="empty small-empty">{loading ? 'Loading…' : 'No important emails right now 🎉'}</div>
          ) : (
            important.map((e) => (
              <EmailRow key={e.id} email={e} categoryMap={categoryMap} regex={regex} compact onClick={() => onOpen(e.id, 'important')} />
            ))
          )}
        </div>

        <div className="card">
          <div className="card-head">
            <h3>🏷️ Keyword categories</h3>
            <button className="link-btn" onClick={() => onNavigate('keywords')}>Edit</button>
          </div>
          <div className="bars">
            {categories.map((c) => {
              const n = counts[c.id] || 0;
              return (
                <button key={c.id} className="bar-row" onClick={() => onNavigate(`cat:${c.id}`)}>
                  <span className="bar-label">{c.icon} {c.name}</span>
                  <span className="bar-track">
                    <span className="bar-fill" style={{ width: `${(n / max) * 100}%`, background: c.color }} />
                  </span>
                  <span className="bar-num">{n}</span>
                </button>
              );
            })}
          </div>
          <p className="muted small bars-note">
            Emails matching {categories.filter((c) => c.important).map((c) => c.name).join(', ')} go to Important.
          </p>
        </div>
      </div>

      <div className="card">
        <div className="card-head">
          <h3>📥 Recent emails</h3>
          <button className="link-btn" onClick={() => onNavigate('all')}>Open inbox</button>
        </div>
        {recent.length === 0 && <div className="empty small-empty">{loading ? 'Loading…' : 'Your inbox is empty.'}</div>}
        {recent.map((e) => (
          <EmailRow key={e.id} email={e} categoryMap={categoryMap} regex={regex} onClick={() => onOpen(e.id, 'all')} />
        ))}
        {hasMore && !loading && (
          <button className="btn-load" onClick={onLoadMore} disabled={loadingMore}>
            {loadingMore ? 'Loading…' : `Load ${pageSize} more emails (${counts.all} loaded)`}
          </button>
        )}
      </div>
    </div>
  );
}
