import Highlight from './Highlight.jsx';
import { avatarColor, formatFullDate, initials } from '../utils/format.js';

// Email HTML is rendered in a sandboxed iframe (no scripts, isolated origin) for safety.
function buildSrcDoc(html) {
  return `<!doctype html><html><head><meta charset="utf-8"><base target="_blank">
<style>body{font-family:Inter,Arial,sans-serif;font-size:14px;line-height:1.6;color:#1e293b;margin:16px;word-wrap:break-word}
img{max-width:100%;height:auto}table{max-width:100%}a{color:#4f46e5}</style></head><body>${html}</body></html>`;
}

export default function EmailDetail({ email, categoryMap, regex, onClose }) {
  const { cls } = email;
  return (
    <article className="detail">
      <div className="detail-toolbar">
        <button className="btn-ghost" onClick={onClose}>← Back</button>
        <a className="btn-ghost" href={`https://mail.google.com/mail/u/0/#inbox/${email.threadId}`} target="_blank" rel="noreferrer">
          Open in Gmail ↗
        </a>
      </div>

      <h1 className="detail-subject">
        <Highlight text={email.subject} regex={regex} />
      </h1>

      {cls.matches.length > 0 ? (
        <div className="match-box">
          <div className="match-title">
            {cls.important ? '⭐ Marked important because it contains:' : 'Matched keywords:'}
            {cls.confidence && <span className={`confidence conf-${cls.confidence.toLowerCase()}`}>{cls.confidence} confidence</span>}
          </div>
          <div className="tags">
            {cls.matches.map((m) => {
              const cat = categoryMap[m.categoryId];
              if (!cat) return null;
              const words = m.hits.length ? m.hits.map((h) => `${h.keyword} (${h.where})`) : m.keywords;
              return (
                <span key={m.categoryId} className="tag" style={{ color: cat.color, background: `${cat.color}1a`, borderColor: `${cat.color}40` }}>
                  {cat.icon} {cat.name}: <strong>{words.join(', ')}</strong>
                </span>
              );
            })}
          </div>
        </div>
      ) : (
        <div className="match-box muted-box">
          No priority keywords found in this email{cls.bulk ? ' (newsletter/promotion — only the subject is checked)' : ''}.
        </div>
      )}

      <div className="detail-meta">
        <div className="avatar avatar-lg" style={{ background: avatarColor(email.fromEmail) }}>{initials(email.fromName)}</div>
        <div className="meta-text">
          <div><strong>{email.fromName}</strong> <span className="muted">&lt;{email.fromEmail}&gt;</span></div>
          <div className="muted small">To: {email.to || 'me'}</div>
        </div>
        <div className="muted small meta-date">{formatFullDate(email.date)}</div>
      </div>

      <div className="detail-body">
        {email.html ? (
          <iframe title="Email content" sandbox="allow-popups allow-popups-to-escape-sandbox" srcDoc={buildSrcDoc(email.html)} />
        ) : (
          <div className="plain-body">
            <Highlight text={email.text || email.snippet} regex={regex} />
          </div>
        )}
      </div>
    </article>
  );
}
