import { useMemo, useState } from 'react';
import EmailRow from './EmailRow.jsx';
import EmailDetail from './EmailDetail.jsx';
import { allKeywordsRegex, byPriority } from '../utils/filter.js';

function viewInfo(view, categories) {
  if (view === 'all') return { title: 'All Mails', icon: '📥', desc: 'Every email loaded from your inbox.' };
  if (view === 'important') return { title: 'Important Emails', icon: '⭐', desc: 'Emails that matched your Urgent, Deadline, Action or Meeting keywords.' };
  if (view === 'unread') return { title: 'Unread', icon: '🔵', desc: 'Emails you have not opened yet.' };
  const cat = categories.find((c) => `cat:${c.id}` === view);
  if (cat) return { title: cat.name, icon: cat.icon, desc: `Matched: ${cat.keywords.join(', ')}`, color: cat.color };
  return { title: 'Mails', icon: '📥', desc: '' };
}

export default function MailView({
  view, emails, categories, search, loading, selectedId, onSelect, onClose, hasMore, loadingMore, onLoadMore,
}) {
  const [sort, setSort] = useState('priority');
  const info = viewInfo(view, categories);
  const categoryMap = useMemo(() => Object.fromEntries(categories.map((c) => [c.id, c])), [categories]);
  const regex = useMemo(() => allKeywordsRegex(categories), [categories]);

  const list = useMemo(() => {
    let out = emails;
    if (view === 'important') out = out.filter((e) => e.cls.important);
    else if (view === 'unread') out = out.filter((e) => e.unread);
    else if (view.startsWith('cat:')) {
      const id = view.slice(4);
      out = out.filter((e) => e.cls.matches.some((m) => m.categoryId === id));
    }
    const q = search.trim().toLowerCase();
    if (q) {
      out = out.filter((e) =>
        `${e.fromName} ${e.fromEmail} ${e.subject} ${e.snippet} ${e.text}`.toLowerCase().includes(q)
      );
    }
    const usePriority = view === 'important' && sort === 'priority';
    return [...out].sort(usePriority ? byPriority : (a, b) => b.date - a.date);
  }, [emails, view, search, sort]);

  const selected = selectedId ? emails.find((e) => e.id === selectedId) : null;

  return (
    <div className={`mail-view ${selected ? 'has-selection' : ''}`}>
      <section className="list-pane">
        <div className="list-header" style={info.color ? { '--accent': info.color } : undefined}>
          <div>
            <h2><span>{info.icon}</span> {info.title} <span className="count-badge">{list.length}</span></h2>
            <p className="muted small">{info.desc}</p>
          </div>
          {view === 'important' && (
            <div className="segmented">
              <button className={sort === 'priority' ? 'on' : ''} onClick={() => setSort('priority')}>Priority</button>
              <button className={sort === 'newest' ? 'on' : ''} onClick={() => setSort('newest')}>Newest</button>
            </div>
          )}
        </div>

        <div className="list-scroll">
          {loading && !emails.length && <Skeleton />}
          {!loading && list.length === 0 && (
            <div className="empty">
              <div className="empty-icon">📭</div>
              <p>{search ? `No emails match “${search}”.` : 'No emails here yet.'}</p>
              {hasMore && <p className="muted small">Try loading more emails from your inbox.</p>}
            </div>
          )}
          {list.map((e) => (
            <EmailRow
              key={e.id}
              email={e}
              categoryMap={categoryMap}
              regex={regex}
              active={e.id === selectedId}
              onClick={() => onSelect(e.id)}
            />
          ))}
          {hasMore && (
            <button className="btn-load" onClick={onLoadMore} disabled={loadingMore}>
              {loadingMore ? 'Loading…' : 'Load more emails'}
            </button>
          )}
        </div>
      </section>

      <section className="detail-pane">
        {selected ? (
          <EmailDetail email={selected} categoryMap={categoryMap} regex={regex} onClose={onClose} />
        ) : (
          <div className="empty detail-empty">
            <div className="empty-icon">✉️</div>
            <p>Select an email to read it</p>
          </div>
        )}
      </section>
    </div>
  );
}

function Skeleton() {
  return Array.from({ length: 6 }, (_, i) => (
    <div className="skeleton-row" key={i}>
      <div className="sk sk-avatar" />
      <div style={{ flex: 1 }}>
        <div className="sk sk-line" style={{ width: '40%' }} />
        <div className="sk sk-line" style={{ width: '80%' }} />
        <div className="sk sk-line" style={{ width: '60%' }} />
      </div>
    </div>
  ));
}
