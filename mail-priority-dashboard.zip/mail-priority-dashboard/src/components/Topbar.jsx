import { avatarColor, initials } from '../utils/format.js';

export default function Topbar({ user, search, onSearch, onRefresh, refreshing, lastSync, onLogout, onMenu }) {
  const email = user?.email || '';
  return (
    <header className="topbar">
      <button className="menu-btn" onClick={onMenu} aria-label="Open menu">☰</button>
      <div className="search">
        <span className="search-icon">🔍</span>
        <input
          value={search}
          onChange={(e) => onSearch(e.target.value)}
          placeholder="Search by sender, subject or content…"
        />
        {search && <button className="search-clear" onClick={() => onSearch('')}>✕</button>}
      </div>

      <div className="topbar-right">
        <button className="btn-icon" onClick={onRefresh} disabled={refreshing} title="Check for new mail">
          <span className={refreshing ? 'spin' : ''}>⟳</span>
          <span className="hide-sm">{refreshing ? 'Syncing…' : lastSync ? `Synced ${new Date(lastSync).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}` : 'Sync'}</span>
        </button>
        <div className="user">
          <div className="avatar" style={{ background: avatarColor(email) }}>{initials(email)}</div>
          <div className="user-info hide-sm">
            <div className="user-email">{email}</div>
            <button className="link-btn" onClick={onLogout}>Sign out</button>
          </div>
          <button className="link-btn show-sm" onClick={onLogout}>Sign out</button>
        </div>
      </div>
    </header>
  );
}
