export default function Sidebar({ view, counts, categories, onNavigate, onClose }) {
  const Item = ({ id, icon, label, count, color, highlight }) => (
    <button
      className={`nav-item ${view === id ? 'active' : ''} ${highlight ? 'nav-important' : ''}`}
      onClick={() => onNavigate(id)}
    >
      <span className="nav-icon" style={color ? { background: `${color}22`, color } : undefined}>{icon}</span>
      <span className="nav-label">{label}</span>
      {count !== undefined && <span className="nav-count">{count}</span>}
    </button>
  );

  return (
    <aside className="sidebar">
      <div className="brand">
        <div className="brand-logo">✉️</div>
        <div>
          <div className="brand-name">MailPriority</div>
          <div className="brand-tag">Smart inbox dashboard</div>
        </div>
        <button className="sidebar-close" onClick={onClose} aria-label="Close menu">✕</button>
      </div>

      <nav className="nav">
        <Item id="dashboard" icon="📊" label="Dashboard" />
        <Item id="all" icon="📥" label="All Mails" count={counts.all} />
        <Item id="important" icon="⭐" label="Important" count={counts.important} highlight />
        <Item id="unread" icon="🔵" label="Unread" count={counts.unread} />

        <div className="nav-section">Keyword filters</div>
        {categories.map((c) => (
          <Item key={c.id} id={`cat:${c.id}`} icon={c.icon} label={c.name} count={counts[c.id] || 0} color={c.color} />
        ))}

        <div className="nav-section">Settings</div>
        <Item id="keywords" icon="🏷️" label="Manage keywords" />
      </nav>
    </aside>
  );
}
