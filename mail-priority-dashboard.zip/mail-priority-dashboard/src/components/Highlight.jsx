// Wraps keyword matches inside text with <mark>.
export default function Highlight({ text = '', regex }) {
  if (!regex || !text) return text;
  const parts = [];
  let last = 0;
  regex.lastIndex = 0;
  let m;
  while ((m = regex.exec(text)) !== null) {
    if (m.index > last) parts.push(text.slice(last, m.index));
    parts.push(<mark key={m.index}>{m[0]}</mark>);
    last = m.index + m[0].length;
    if (m[0].length === 0) regex.lastIndex += 1;
  }
  if (last < text.length) parts.push(text.slice(last));
  return <>{parts}</>;
}
