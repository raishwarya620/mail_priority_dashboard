import { useState } from 'react';

const COLORS = ['#ef4444', '#f97316', '#eab308', '#22c55e', '#14b8a6', '#0ea5e9', '#6366f1', '#8b5cf6', '#ec4899', '#64748b'];

function CategoryCard({ cat, onUpdate, onDelete }) {
  const [input, setInput] = useState('');

  const add = () => {
    const words = input.split(',').map((w) => w.trim()).filter(Boolean);
    const existing = new Set(cat.keywords.map((k) => k.toLowerCase()));
    const fresh = words.filter((w) => !existing.has(w.toLowerCase()));
    if (fresh.length) onUpdate({ ...cat, keywords: [...cat.keywords, ...fresh] });
    setInput('');
  };

  return (
    <div className="kw-card" style={{ '--accent': cat.color }}>
      <div className="kw-head">
        <span className="kw-icon" style={{ background: `${cat.color}22` }}>{cat.icon}</span>
        <input className="kw-name" value={cat.name} onChange={(e) => onUpdate({ ...cat, name: e.target.value })} />
        <button className="btn-ghost danger" onClick={onDelete} title="Delete category">🗑</button>
      </div>

      <label className="toggle">
        <input type="checkbox" checked={cat.important} onChange={(e) => onUpdate({ ...cat, important: e.target.checked })} />
        <span className="toggle-track"><span className="toggle-thumb" /></span>
        <span>Show in <strong>Important</strong> list</span>
      </label>

      <div className="chips">
        {cat.keywords.map((k) => (
          <span key={k} className="chip" style={{ borderColor: `${cat.color}55`, background: `${cat.color}12` }}>
            {k}
            <button onClick={() => onUpdate({ ...cat, keywords: cat.keywords.filter((x) => x !== k) })} aria-label={`Remove ${k}`}>×</button>
          </span>
        ))}
        {cat.keywords.length === 0 && <span className="muted small">No keywords yet</span>}
      </div>

      <div className="kw-add">
        <input
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={(e) => e.key === 'Enter' && add()}
          placeholder="Add keyword (comma separated)…"
        />
        <button className="btn-primary sm" onClick={add}>Add</button>
      </div>
    </div>
  );
}

export default function KeywordManager({ categories, onChange, onReset }) {
  const [newName, setNewName] = useState('');
  const [newColor, setNewColor] = useState(COLORS[6]);

  const update = (id, next) => onChange(categories.map((c) => (c.id === id ? next : c)));
  const remove = (id) => {
    if (window.confirm('Delete this category and its keywords?')) onChange(categories.filter((c) => c.id !== id));
  };
  const move = (index, dir) => {
    const next = [...categories];
    const [item] = next.splice(index, 1);
    next.splice(index + dir, 0, item);
    onChange(next);
  };
  const addCategory = () => {
    const name = newName.trim();
    if (!name) return;
    onChange([
      ...categories,
      { id: `custom-${Date.now()}`, name, icon: '🏷️', color: newColor, important: true, keywords: [] },
    ]);
    setNewName('');
  };

  return (
    <div className="keywords-page">
      <div className="page-head">
        <div>
          <h2>🏷️ Manage keywords</h2>
          <p className="muted">
            Emails are checked (case-insensitive, whole words) in the subject and body. Higher categories have higher
            priority — use the arrows to reorder. Changes apply instantly and are saved in this browser.
          </p>
        </div>
        <button className="btn-outline" onClick={() => window.confirm('Reset all keywords to defaults?') && onReset()}>
          Reset to defaults
        </button>
      </div>

      <div className="kw-grid">
        {categories.map((cat, i) => (
          <div key={cat.id} className="kw-wrap">
            <div className="kw-order">
              <button disabled={i === 0} onClick={() => move(i, -1)} title="Higher priority">▲</button>
              <span>{i + 1}</span>
              <button disabled={i === categories.length - 1} onClick={() => move(i, 1)} title="Lower priority">▼</button>
            </div>
            <CategoryCard cat={cat} onUpdate={(next) => update(cat.id, next)} onDelete={() => remove(cat.id)} />
          </div>
        ))}

        <div className="kw-card kw-new">
          <h3>➕ New category</h3>
          <input value={newName} onChange={(e) => setNewName(e.target.value)} onKeyDown={(e) => e.key === 'Enter' && addCategory()} placeholder="Category name, e.g. Payments" />
          <div className="swatches">
            {COLORS.map((c) => (
              <button key={c} className={`swatch ${newColor === c ? 'on' : ''}`} style={{ background: c }} onClick={() => setNewColor(c)} aria-label={c} />
            ))}
          </div>
          <button className="btn-primary" onClick={addCategory}>Create category</button>
        </div>
      </div>
    </div>
  );
}
