// Gmail integration using Google Identity Services (OAuth 2.0 token flow)
// and the Gmail REST API. Everything runs in the browser – no backend needed.

import { cleanBody } from '../utils/filter.js';
import { clearCache, getCached, putCached } from './cache.js';

const CLIENT_ID = import.meta.env.VITE_GOOGLE_CLIENT_ID;
const SCOPES = 'https://www.googleapis.com/auth/gmail.readonly';
const API = 'https://gmail.googleapis.com/gmail/v1/users/me';
const TOKEN_KEY = 'mpd_token';

export class AuthError extends Error {}

export function isConfigured() {
  return Boolean(CLIENT_ID) && !CLIENT_ID.startsWith('your-client-id');
}

// ---------- Auth ----------

function waitForGis(timeoutMs = 10000) {
  return new Promise((resolve, reject) => {
    const start = Date.now();
    (function check() {
      if (window.google?.accounts?.oauth2) return resolve(window.google.accounts.oauth2);
      if (Date.now() - start > timeoutMs) {
        return reject(new Error('Could not load Google sign-in. Check your internet connection.'));
      }
      setTimeout(check, 100);
    })();
  });
}

export function getStoredToken() {
  try {
    const saved = JSON.parse(sessionStorage.getItem(TOKEN_KEY));
    if (saved && saved.expiresAt > Date.now() + 60_000) return saved.accessToken;
  } catch {
    /* ignore */
  }
  return null;
}

export function clearToken() {
  const token = getStoredToken();
  sessionStorage.removeItem(TOKEN_KEY);
  clearCache(); // don't leave emails in this browser after signing out
  if (token && window.google?.accounts?.oauth2) {
    window.google.accounts.oauth2.revoke(token, () => {});
  }
}

export async function signIn() {
  if (!isConfigured()) {
    throw new Error('Google Client ID is missing. Add VITE_GOOGLE_CLIENT_ID to your .env file and restart "npm run dev".');
  }
  const oauth2 = await waitForGis();
  return new Promise((resolve, reject) => {
    const client = oauth2.initTokenClient({
      client_id: CLIENT_ID,
      scope: SCOPES,
      callback: (resp) => {
        if (resp.error) return reject(new Error(resp.error_description || resp.error));
        if (!oauth2.hasGrantedAllScopes(resp, SCOPES)) {
          return reject(new Error('Please allow "Read your email" permission so the dashboard can show your mails.'));
        }
        const expiresAt = Date.now() + Number(resp.expires_in) * 1000;
        sessionStorage.setItem(TOKEN_KEY, JSON.stringify({ accessToken: resp.access_token, expiresAt }));
        resolve(resp.access_token);
      },
      error_callback: (err) => {
        reject(new Error(err?.type === 'popup_closed' ? 'Sign-in popup was closed.' : err?.message || 'Sign-in failed.'));
      },
    });
    client.requestAccessToken();
  });
}

// ---------- API helpers ----------

// Gmail has a per-user quota (each message download = 5 units). When Google answers
// "quota exceeded / rate limit", every request pauses together and retries with backoff
// instead of failing.
const MAX_RETRIES = 6;
let pausedUntil = 0;
let rateLimitListener = null;

export function onRateLimit(fn) {
  rateLimitListener = fn;
}

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

function isRateLimited(status, body) {
  if (status === 429) return true;
  if (status !== 403) return false;
  const reason = body?.error?.errors?.[0]?.reason || '';
  const msg = body?.error?.message || '';
  return /rateLimit|quota/i.test(reason) || /quota|rate limit/i.test(msg) || body?.error?.status === 'RESOURCE_EXHAUSTED';
}

async function api(path, token, attempt = 0) {
  const wait = pausedUntil - Date.now();
  if (wait > 0) await sleep(wait);

  const res = await fetch(`${API}${path}`, { headers: { Authorization: `Bearer ${token}` } });
  if (res.status === 401) {
    sessionStorage.removeItem(TOKEN_KEY);
    throw new AuthError('Your session expired. Please sign in again.');
  }
  if (!res.ok) {
    let body = null;
    try {
      body = await res.json();
    } catch {
      /* ignore */
    }
    if (isRateLimited(res.status, body)) {
      if (attempt >= MAX_RETRIES) {
        throw new Error('Gmail is limiting requests right now (per-minute quota). Wait a minute, then press Sync or Load more again.');
      }
      const retryAfter = Number(res.headers.get('Retry-After'));
      const delay = retryAfter > 0 ? retryAfter * 1000 : Math.min(32000, 2000 * 2 ** attempt) + Math.random() * 1000;
      // Pause all requests (not just this one) so we stop hammering the API.
      pausedUntil = Math.max(pausedUntil, Date.now() + delay);
      rateLimitListener?.(Math.ceil((pausedUntil - Date.now()) / 1000));
      return api(path, token, attempt + 1);
    }
    const err = new Error(body?.error?.message || `Gmail API error (${res.status})`);
    err.status = res.status;
    throw err;
  }
  return res.json();
}

// Run async tasks with limited concurrency (keeps us well under Gmail's per-second limit).
async function mapLimit(items, limit, fn) {
  const results = new Array(items.length);
  let i = 0;
  const workers = Array.from({ length: Math.min(limit, items.length) }, async () => {
    while (i < items.length) {
      const idx = i++;
      results[idx] = await fn(items[idx]);
    }
  });
  await Promise.all(workers);
  return results;
}

export function getProfile(token) {
  return api('/profile', token);
}

// Uses the INBOX label (not a search query): label lists are updated instantly, while
// Gmail search (q=in:inbox) can lag behind by seconds or minutes for brand-new mail.
export async function listMessageIds(token, { pageToken, maxResults = 30 } = {}) {
  const params = new URLSearchParams({ maxResults: String(maxResults), labelIds: 'INBOX' });
  if (pageToken) params.set('pageToken', pageToken);
  const data = await api(`/messages?${params}`, token);
  return { ids: (data.messages || []).map((m) => m.id), nextPageToken: data.nextPageToken || null };
}

// Returns parsed messages in the same order as ids. Already-downloaded messages come
// from the local cache, so only new ones cost Gmail quota.
export async function getMessages(token, ids, account = 'me') {
  const cached = await getCached(account, ids);
  const missing = ids.filter((id) => !cached[id]);
  const fresh = (await mapLimit(missing, 4, (id) => api(`/messages/${id}?format=full`, token))).map(parseMessage);
  await putCached(account, fresh);
  const byId = { ...cached };
  fresh.forEach((m) => (byId[m.id] = m));
  return ids.map((id) => byId[id]).filter(Boolean);
}

// One cheap call that returns which inbox emails are unread, used to keep the
// read/unread state of cached emails correct.
export async function getUnreadIds(token) {
  const params = new URLSearchParams({ maxResults: '500' });
  params.append('labelIds', 'INBOX');
  params.append('labelIds', 'UNREAD');
  const data = await api(`/messages?${params}`, token);
  return { ids: new Set((data.messages || []).map((m) => m.id)), complete: !data.nextPageToken };
}

// Everything that changed in the mailbox since `startHistoryId` (real-time sync).
// Cheap (2 quota units) and instant. Throws with status 404 if the id is too old.
export async function getChanges(token, startHistoryId) {
  const added = new Set();
  const removed = new Set();
  const unread = {}; // id -> true/false
  let historyId = startHistoryId;
  let pageToken = null;

  do {
    const params = new URLSearchParams({ startHistoryId, maxResults: '500' });
    if (pageToken) params.set('pageToken', pageToken);
    const data = await api(`/history?${params}`, token);
    (data.history || []).forEach((h) => {
      (h.messagesAdded || []).forEach(({ message }) => {
        if (message.labelIds?.includes('INBOX')) {
          added.add(message.id);
          removed.delete(message.id);
        }
      });
      (h.messagesDeleted || []).forEach(({ message }) => {
        removed.add(message.id);
        added.delete(message.id);
      });
      (h.labelsAdded || []).forEach(({ message, labelIds }) => {
        if (labelIds.includes('INBOX')) {
          added.add(message.id); // moved back to inbox
          removed.delete(message.id);
        }
        if (labelIds.includes('UNREAD')) unread[message.id] = true;
      });
      (h.labelsRemoved || []).forEach(({ message, labelIds }) => {
        if (labelIds.includes('INBOX')) {
          removed.add(message.id); // archived / deleted
          added.delete(message.id);
        }
        if (labelIds.includes('UNREAD')) unread[message.id] = false;
      });
    });
    historyId = data.historyId || historyId;
    pageToken = data.nextPageToken;
  } while (pageToken);

  return { historyId, added: [...added], removed: [...removed], unread };
}

// ---------- Parsing ----------

function decodeBase64Url(data = '') {
  const b64 = data.replace(/-/g, '+').replace(/_/g, '/');
  const bin = atob(b64);
  const bytes = Uint8Array.from(bin, (c) => c.charCodeAt(0));
  return new TextDecoder('utf-8').decode(bytes);
}

function walkParts(part, acc) {
  if (!part) return acc;
  const mime = part.mimeType || '';
  if (part.filename && part.body?.attachmentId) acc.attachments += 1;
  else if (mime === 'text/plain' && part.body?.data && !acc.text) acc.text = decodeBase64Url(part.body.data);
  else if (mime === 'text/html' && part.body?.data && !acc.html) acc.html = decodeBase64Url(part.body.data);
  (part.parts || []).forEach((p) => walkParts(p, acc));
  return acc;
}

// Convert HTML to text while keeping line breaks between blocks/cells, so words in
// separate <td>/<div>/<p> elements don't get glued together ("UrgentMeeting").
export function htmlToText(html) {
  const withBreaks = html.replace(/<(?:br|\/p|\/div|\/tr|\/li|\/h[1-6]|\/td|\/th|\/table|\/blockquote)\b[^>]*>/gi, '$&\n');
  const doc = new DOMParser().parseFromString(withBreaks, 'text/html');
  doc.querySelectorAll('style,script,head,title').forEach((n) => n.remove());
  // Gmail puts quoted replies in these containers – drop them before matching.
  doc.querySelectorAll('.gmail_quote,.gmail_signature,blockquote').forEach((n) => n.remove());
  return (doc.body?.textContent || '')
    .replace(/[ \t ]+/g, ' ')
    .replace(/\n\s*\n+/g, '\n')
    .trim();
}

function decodeEntities(str) {
  const el = document.createElement('textarea');
  el.innerHTML = str;
  return el.value;
}

function parseFrom(value = '') {
  const m = value.match(/^\s*"?([^"<]*?)"?\s*<([^>]+)>/);
  if (m) return { name: m[1].trim() || m[2], email: m[2] };
  return { name: value.trim(), email: value.trim() };
}

export function parseMessage(msg) {
  const headers = {};
  (msg.payload?.headers || []).forEach((h) => {
    headers[h.name.toLowerCase()] = h.value;
  });
  const { text, html, attachments } = walkParts(msg.payload, { text: '', html: '', attachments: 0 });
  const from = parseFrom(headers.from);
  // Some senders put only "view this email in your browser" in text/plain – use the HTML then.
  const plain = text.trim();
  const bodyText = (plain.length >= 120 || !html ? plain : htmlToText(html)).slice(0, 20000);
  const labels = msg.labelIds || [];

  // Newsletters / promotions: their marketing copy ("act now", "today only") must not
  // make them "important", so the classifier only looks at their subject.
  const bulk =
    labels.some((l) => ['CATEGORY_PROMOTIONS', 'CATEGORY_SOCIAL', 'CATEGORY_FORUMS'].includes(l)) ||
    Boolean(headers['list-unsubscribe']) ||
    /bulk|list|junk/i.test(headers.precedence || '');

  return {
    id: msg.id,
    threadId: msg.threadId,
    fromName: from.name,
    fromEmail: from.email,
    to: headers.to || '',
    subject: headers.subject || '(no subject)',
    snippet: decodeEntities(msg.snippet || ''),
    date: Number(msg.internalDate) || Date.parse(headers.date) || Date.now(),
    unread: labels.includes('UNREAD'),
    starred: labels.includes('STARRED'),
    attachments,
    bulk,
    html,
    text: bodyText,
    matchText: cleanBody(bodyText || decodeEntities(msg.snippet || '')),
  };
}
