// Small IndexedDB cache for already-downloaded emails, so reloading the page does not
// download every message again (each download costs Gmail API quota).

const DB_NAME = 'mail-priority';
const STORE = 'messages';
const VERSION = 1;

let dbPromise = null;

function openDb() {
  if (!dbPromise) {
    dbPromise = new Promise((resolve) => {
      try {
        const req = indexedDB.open(DB_NAME, VERSION);
        req.onupgradeneeded = () => req.result.createObjectStore(STORE);
        req.onsuccess = () => resolve(req.result);
        req.onerror = () => resolve(null);
      } catch {
        resolve(null); // private mode / blocked storage: just run without a cache
      }
    });
  }
  return dbPromise;
}

const key = (account, id) => `${account}:${id}`;

export async function getCached(account, ids) {
  const db = await openDb();
  if (!db || !ids.length) return {};
  return new Promise((resolve) => {
    const out = {};
    const tx = db.transaction(STORE, 'readonly');
    const store = tx.objectStore(STORE);
    ids.forEach((id) => {
      const req = store.get(key(account, id));
      req.onsuccess = () => {
        if (req.result) out[id] = req.result;
      };
    });
    tx.oncomplete = () => resolve(out);
    tx.onerror = () => resolve(out);
  });
}

export async function putCached(account, messages) {
  const db = await openDb();
  if (!db || !messages.length) return;
  await new Promise((resolve) => {
    const tx = db.transaction(STORE, 'readwrite');
    const store = tx.objectStore(STORE);
    messages.forEach((m) => store.put(m, key(account, m.id)));
    tx.oncomplete = resolve;
    tx.onerror = resolve;
  });
}

export async function clearCache() {
  const db = await openDb();
  if (!db) return;
  await new Promise((resolve) => {
    const tx = db.transaction(STORE, 'readwrite');
    tx.objectStore(STORE).clear();
    tx.oncomplete = resolve;
    tx.onerror = resolve;
  });
}
