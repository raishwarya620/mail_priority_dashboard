// Accuracy test for keyword detection. Run with:  npm run test:filter
import { DEFAULT_CATEGORIES } from '../src/config/keywords.js';
import { classifyEmail, compileCategories } from '../src/utils/filter.js';

const compiled = compileCategories(DEFAULT_CATEGORIES);

// [description, email, expected important?, expected categories (must all be present), forbidden categories]
const cases = [
  ['urgent in subject', { subject: 'URGENT: Production server down', text: 'The server is down.' }, true, ['urgent']],
  ['ASAP in body', { subject: 'Server issue', text: 'Please fix this ASAP, customers are affected.' }, true, ['urgent']],
  ['word form: urgently', { subject: 'Hello', text: 'We urgently need the signed documents.' }, true, ['urgent']],
  ['negation: not urgent', { subject: 'Small question', text: 'Not urgent, whenever you have time.' }, false, [], ['urgent']],
  ['negation: non-urgent', { subject: 'Non-urgent: printer', text: 'The printer is slow.' }, false, [], ['urgent']],
  ['negation: no action required', { subject: 'Report ready', text: 'No action required from your side.' }, false, [], ['action']],
  ['deadline phrase by Monday', { subject: 'Timesheet', text: 'Please send your timesheet by Monday.' }, true, ['deadline', 'action']],
  ['last date', { subject: 'Fee payment', text: 'The last date for fee payment is 5th October.' }, true, ['deadline']],
  ['due in subject', { subject: 'Invoice #4521 due tomorrow', text: 'Friendly reminder.' }, true, ['deadline']],
  ['"due" inside "procedure" must not match', { subject: 'New procedure', text: 'We changed the procedure for access cards.' }, false, [], ['deadline']],
  ['weak word alone in body is not enough', { subject: 'Photos from the trip', text: 'Here are the photos I took today at the beach.' }, false, [], ['deadline']],
  ['two weak words together are enough', { subject: 'Proposal', text: 'Could you review it and approve it?' }, true, ['action']],
  ['word form: approval / reviewed', { subject: 'Budget', text: 'Waiting for your approval after it is reviewed.' }, true, ['action']],
  ['word form: confirmation', { subject: 'Booking', text: 'Kindly send the confirmation for the booking.' }, true, ['action']],
  ['word form: submitted/submission deadline', { subject: 'Assignment deadline', text: 'Must be submitted online.' }, true, ['deadline']],
  ['please respond', { subject: 'Survey', text: 'Please respond before Friday.' }, true, ['action']],
  ['meeting', { subject: 'Team meeting at 3pm', text: 'See you there.' }, true, ['meeting']],
  ['word form: meetings / rescheduled', { subject: 'Calendar', text: 'All meetings are rescheduled to next week.' }, true, ['meeting']],
  ['appointment', { subject: 'Your appointment', text: 'Dr. Mehta, Thursday 5 PM.' }, true, ['meeting']],
  ['"call" inside "recall" must not match', { subject: 'Product recall', text: 'We recall batch 42.' }, false, [], ['meeting']],
  ['quoted reply is ignored', {
    subject: 'Re: lunch',
    text: 'Sounds good, see you!\n\nOn Mon, 1 Sep 2026 at 10:00, Boss <b@x.com> wrote:\n> This is URGENT, respond immediately\n',
  }, false, [], ['urgent']],
  ['signature is ignored', { subject: 'Thanks', text: 'Thanks for lunch!\n-- \nJohn | Critical Systems Team | Emergency line 911' }, false, [], ['urgent']],
  ['newsletter body is ignored', {
    subject: 'Your weekly digest', bulk: true, text: 'Act immediately! Urgent deal ends today. Unsubscribe here.',
  }, false, ['low'], ['urgent', 'deadline']],
  ['newsletter with keyword in subject still counts', {
    subject: 'Deadline extended for project submission', bulk: true, text: 'Big sale!',
  }, true, ['deadline']],
  ['footer lines ignored', {
    subject: 'Hello', text: 'Hi, just saying hi.\nYou are receiving this because you signed up. Update your preferences or unsubscribe.',
  }, false, [], ['low']],
  ['FYI low priority', { subject: 'FYI: office closed on Friday', text: 'Enjoy the long weekend.' }, false, ['low']],
  ['multiple spaces in phrase', { subject: 'Reminder', text: 'Submit the report   by   Monday please.' }, true, ['deadline']],
  ['words split across html cells stay separate', { subject: 'Status', text: 'Priority\nUrgent\nOwner' }, true, ['urgent']],
  ['critical security alert', { subject: 'Critical security alert', text: 'New sign-in detected.' }, true, ['urgent']],
  ['polite request makes weak word count', { subject: 'Hotel', text: 'Kindly confirm the booking.' }, true, ['action']],
  ['negated polite request', { subject: 'Hotel', text: 'No need to confirm the booking.' }, false, [], ['action']],
  ['"today" in a casual email', { subject: 'Hi', text: 'Great seeing you today! Let us catch up soon.' }, false, []],
  ['emergencies plural', { subject: 'Info', text: 'For emergencies contact the front desk.' }, true, ['urgent']],
];

let pass = 0;
cases.forEach(([name, email, important, must = [], forbid = []]) => {
  const cls = classifyEmail(email, compiled);
  const ids = cls.matches.map((m) => m.categoryId);
  const errors = [];
  if (cls.important !== important) errors.push(`important=${cls.important}, expected ${important}`);
  must.forEach((id) => !ids.includes(id) && errors.push(`missing ${id}`));
  forbid.forEach((id) => ids.includes(id) && errors.push(`should not match ${id}`));
  if (errors.length) {
    console.log(`✗ ${name}\n    ${errors.join('; ')}\n    got: ${JSON.stringify(cls.matches.map((m) => [m.categoryId, m.keywords, m.score]))}`);
  } else {
    pass += 1;
    console.log(`✓ ${name}`);
  }
});
console.log(`\n${pass}/${cases.length} passed`);
process.exit(pass === cases.length ? 0 : 1);
