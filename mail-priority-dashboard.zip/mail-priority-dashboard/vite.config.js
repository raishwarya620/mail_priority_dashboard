import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

// Port 5175 must match the "Authorized JavaScript origin" in Google Cloud
// (http://localhost:5175). strictPort makes Vite fail instead of silently switching ports.
export default defineConfig({
  plugins: [react()],
  server: { port: 5175, strictPort: true },
});
